# SportDashLauncher
Landscape Android home-screen launcher prototype with a GPS-based speed display. Speed is read from Android GPS location; it is not an OBD/CAN engine-data reader.
