package com.sportdash.launcher

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Button
import android.widget.Toast

class MainActivity : Activity(), LocationListener {
    private lateinit var speed: TextView
    private lateinit var status: TextView
    private lateinit var lm: LocationManager
    private val red = Color.rgb(255, 55, 45)
    private val bg = Color.rgb(9, 10, 13)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        lm = getSystemService(LOCATION_SERVICE) as LocationManager
        buildScreen()
        requestGps()
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply { this.text = text; textSize = size; setTextColor(color); gravity = Gravity.CENTER; if (bold) setTypeface(Typeface.DEFAULT, Typeface.BOLD) }

    private fun buildScreen() {
        val outer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(28, 12, 28, 12); setBackgroundColor(bg) }
        outer.addView(label("SPORT  /  DASH", 18f, red, true), LinearLayout.LayoutParams(-1, 42))
        speed = label("--", 112f, Color.WHITE, true)
        outer.addView(speed, LinearLayout.LayoutParams(-1, 190))
        outer.addView(label("KM/H  •  GPS SPEED", 16f, red, true), LinearLayout.LayoutParams(-1, 34))
        status = label("Waiting for GPS signal…", 14f, Color.LTGRAY)
        outer.addView(status, LinearLayout.LayoutParams(-1, 42))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        listOf("MAPS", "MUSIC", "RADIO", "APPS").forEach { name ->
            val b = Button(this).apply { text = name; textSize = 13f; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(48, 20, 22)); setOnClickListener {
                when(name) {
                    "MAPS" -> launchPackage("com.google.android.apps.maps")
                    "MUSIC" -> launchPackage("com.google.android.apps.youtube.music")
                    "RADIO" -> Toast.makeText(this@MainActivity, "Open your radio app from APPS", Toast.LENGTH_SHORT).show()
                    else -> startActivity(android.content.Intent(android.provider.Settings.ACTION_SETTINGS))
                }
            } }
            row.addView(b, LinearLayout.LayoutParams(0, 68, 1f).apply { setMargins(8, 8, 8, 8) })
        }
        outer.addView(row, LinearLayout.LayoutParams(-1, 88))
        outer.addView(label("REDLINE  •  DRIVE SAFE", 12f, Color.DKGRAY, true), LinearLayout.LayoutParams(-1, 34))
        setContentView(outer)
    }

    private fun launchPackage(pkg: String) {
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent != null) startActivity(intent) else Toast.makeText(this, "App not installed", Toast.LENGTH_SHORT).show()
    }

    private fun requestGps() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 10); return
        }
        try {
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500, 0f, this)
                status.text = "GPS active • waiting for movement"
                lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)?.let { onLocationChanged(it) }
            } else status.text = "Enable GPS in device settings"
        } catch (_: SecurityException) { status.text = "GPS permission required" }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == 10 && results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) requestGps() else status.text = "Allow location permission to show GPS speed"
    }
    override fun onLocationChanged(location: Location) {
        val kmh = if (location.hasSpeed()) location.speed * 3.6f else 0f
        speed.text = String.format("%.0f", kmh)
        status.text = "GPS LOCKED  •  ±${location.accuracy.toInt()} m"
    }
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) { status.text = "GPS disabled" }
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onDestroy() { super.onDestroy(); try { lm.removeUpdates(this) } catch (_: Exception) {} }
}
